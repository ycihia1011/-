﻿using System;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;

namespace InsuranceWeb.Commons
{
    public class EddaHelper
    {
        private static string pw = "djif6482zcqwmmuz";
        private static string url = System.Configuration.ConfigurationManager.AppSettings["eDDAUrl"].ToString();

        /// <summary>
        /// 保存同意授權Log
        /// </summary>
        /// <param name="clientId">客戶身份證</param>
        /// <returns></returns>
        public static bool SaveEddaAgreementLog(string clientId)
        {
            var postData = "operation=agreement_log&acct=webview&pwd=ae490cec50db24e1aca41ce7da25c1fbb67d1932&aid=" + clientId;
            var result = InsuranceWeb.Commons.Helper.DeserializeJson<EddaLogMessage>(GetWebResponseByPost(url + "/CGWebPrototype/CG.servlet", postData));
            return result == null 
                ? false
                : result.Message.Contains("success") ;
        }
        /// <summary>
        /// 加密網銀授權資料
        /// </summary>
        /// <param name="source">要加密的資料</param>
        /// <returns></returns>
        public static string EncryptData(string source)
        {
            //. 加密
            byte[] key = Encoding.ASCII.GetBytes(Genkey());
            byte[] Tex = Encoding.UTF8.GetBytes(source);
            RijndaelManaged AES = new RijndaelManaged();
            var strGetValue = string.Empty;
            try
            {
                AES.Key = key;
                AES.Mode = CipherMode.CBC;
                AES.Padding = PaddingMode.PKCS7;
                ICryptoTransform transform = AES.CreateEncryptor();
                byte[] outputData = transform.TransformFinalBlock(Tex, 0, Tex.Length);
                strGetValue = Convert.ToBase64String(outputData);
            }
            finally
            {
                AES.Clear();
                AES.Dispose();
            }
            return strGetValue;
        }
        /// <summary>
        /// 解密網銀授權資料
        /// </summary>
        /// <param name="source">要解密的資料</param>
        /// <returns></returns>
        public static string DecrypteData(string source)
        {
            //解碼
            byte[] key = Encoding.ASCII.GetBytes(Genkey());
            byte[] Tex = Convert.FromBase64String(source);
            RijndaelManaged AES = new RijndaelManaged();
            var strGetValue = string.Empty;
            try
            {
                AES.Key = key;
                AES.Mode = CipherMode.CBC;
                AES.Padding = PaddingMode.PKCS7;
                ICryptoTransform transform = AES.CreateDecryptor();
                byte[] outputData = transform.TransformFinalBlock(Tex, 0, Tex.Length);
                strGetValue = Encoding.UTF8.GetString(outputData);
            }
            finally
            {
                AES.Clear();
                AES.Dispose();
            }
            return strGetValue;
        }

        private static string Genkey()
        {
            var key = string.Empty;
            for (var i = 0; i < pw.Length; i++)
            {
                var idx = pw.Length % (i + 1);
                idx = idx + 3;
                idx = idx % (i + 1);
                if (idx <= 0) idx = 1;
                if (idx >= pw.Length) idx = idx % (i + 1);
                key = String.Format("{0}{1}", key, pw.Substring(idx, 1));
            }
            return key;
        }
        /// <summary>
        /// 產生票交所指定之驗證資料
        /// </summary>
        /// <param name="DateData">8位數日期</param>
        /// <param name="value">來源資料</param>
        /// <returns></returns>
        public static byte[] GetMAC(string DateData, string value,string partA,string partB)
        {
            byte[] mac = null;
            byte[] MAC = new byte[4];

            //處理MAC DATA
            byte[] byte_MACDATA = GetMACDATA(value);

            //處理ICV0
            byte[] byte_ICV0 = GetValueTobyte(DateData.PadRight(16, '0'));

            //處理Key
            byte[] byte_Key = GetValueTobyte(GetClearKey(partA,partB));

            //計算MAC
            using (TripleDES TDES = TripleDES.Create())
            {
                TDES.Mode = CipherMode.CBC;
                TDES.Padding = PaddingMode.None;
                TDES.Key = byte_Key;
                TDES.IV = byte_ICV0;
                using (ICryptoTransform encrypt_TDES = TDES.CreateEncryptor())
                {
                    mac = encrypt_TDES.TransformFinalBlock(byte_MACDATA, 0, byte_MACDATA.Length);
                }
            }


            //取出最後一組8byte的前4byte
            for (int i = mac.Length - 8, ii = 0; i < mac.Length - 4; i++, ii++)
            {
                MAC[ii] = mac[i];
            }

            return MAC;
        }
        private static string GetClearKey(string partA, string partB)
        {
            string APart = string.Empty, BPart = string.Empty, ClearKey = "".PadRight(32, '0');

            // 取得資庫來源
            //var eddaProcessRepository = new InsuranceWeb.
            //Model.XORKey xorkey = dal.startGetKey(delegate (bool success, Object msg)
            //{
            //    if (!success) { }// 記 Log
            //});

            APart = partA; // xorkey.PartA;
            BPart = partB; // xorkey.PartB;

            if (APart.Length == BPart.Length)
            {
                byte[] byte_ClearKey = new byte[APart.Length / 2];

                for (int i = 0; i < byte_ClearKey.Length; i++)
                {
                    int intA = int.Parse(APart.Substring(i * 2, 2), System.Globalization.NumberStyles.HexNumber);
                    int intB = int.Parse(BPart.Substring(i * 2, 2), System.Globalization.NumberStyles.HexNumber);
                    byte_ClearKey[i] = (byte)(intA ^ intB);
                }

                StringBuilder stringBuilder = new StringBuilder(byte_ClearKey.Length * 2);
                foreach (byte item in byte_ClearKey)
                {
                    stringBuilder.AppendFormat("{0:x2}", item);
                }
                ClearKey = stringBuilder.ToString().ToUpper();
            }

            return ClearKey;
        }
        private static byte[] GetMACDATA(string value)
        {
            int vL = 0;
            if (value.Length % 8 > 0)
            {
                vL = 8 - (value.Length % 8);
            }
            byte[] byte_MACDATA = new byte[value.Length + vL];

            int i = 0;
            foreach (byte item in value)
            {
                byte_MACDATA[i] = item;
                i++;
            }

            return byte_MACDATA;
        }
        private static byte[] GetValueTobyte(string value)
        {
            byte[] byte_value = new byte[value.Length / 2];

            for (int i = 0; i < byte_value.Length; i++)
            {
                byte_value[i] = (byte)int.Parse(value.Substring(i * 2, 1) + value.Substring(i * 2 + 1, 1), System.Globalization.NumberStyles.HexNumber);
            }

            return byte_value;
        }

        /// <summary>
        /// 檢查票交回傳的mac是否正常
        /// </summary>
        /// <param name="dateStr"></param>
        /// <param name="respdataForMac"></param>
        /// <param name="respMacBytes"></param>
        /// <returns></returns>
        public static bool ExamResponseMac(string dateStr, string respdataForMac, byte[] respMacBytes,string partA,string partB)
        {
            byte[] bytes = GetMAC(dateStr.Substring(0, 8), respdataForMac, partA, partB);
            string tmpmac = Convert.ToBase64String(bytes);
            string respmacStr = Convert.ToBase64String(respMacBytes);
            if (tmpmac.Equals(respmacStr))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// 獲取eDDA授權書資料
        /// </summary>
        /// <param name="url">全景eDDA授權書網址</param>
        /// <returns></returns>
        public static string GetAgreement(string url)
        {
            var agreementResult = GetWebResponseByPost(url + "/CGWebPrototype/CG.servlet", "operation=get_agreement&acct=webview&pwd=ae490cec50db24e1aca41ce7da25c1fbb67d1932&agreementName=1");
            return agreementResult;
        }
        /// <summary>
        /// 以post方式 呼叫 webrequest
        /// </summary>
        /// <param name="tokenUrl"></param>
        /// <param name="postData"></param>
        /// <returns></returns>
        public static string GetWebResponseByPost(string tokenUrl, string postData)
        {
            try
            {
                byte[] data = Encoding.ASCII.GetBytes(postData);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(tokenUrl);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;
                using (Stream stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                return new StreamReader(response.GetResponseStream()).ReadToEnd();
            }
            catch (Exception ex)
            {
                return "eDDA > GetWebResponseByPost 錯誤:" + ex.ToString();
            }
        }
        /// <summary>
        /// EDDA 讀卡授權
        /// </summary>
        /// <param name="postStr"></param>
        /// <returns></returns>
        public static string AuthCard(string postStr)
        {
            var authResult = GetWebResponseByPost(url + "/CGWebPrototype/CG.servlet", postStr);
            return authResult;
        }
        /// <summary>
        /// 將Dict Value 轉為HttpPost格式:{0}={1}
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string BuildParamenter(string id, object value)
        {
            string empty = string.Empty;
            string str = string.Empty;
            if (value != null)
            {
                empty = (!value.GetType().Equals(typeof(DateTime))
                    ? value.ToString()
                    : ((DateTime)value).ToString("yyyy/MM/dd HH:mm:ss"));
            }
            return string.Format("&{0}={1}", id, empty);
        }
        /// <summary>
        /// 照順序排序URL參數
        /// </summary>
        /// <param name="keyValues"></param>
        /// <returns></returns>
        public static string GenerateQueryString(Dictionary<string, object> keyValues)
        {
            string str = string.Empty;
            keyValues.OrderBy(x => x.Key)
                .ToList()
                .ForEach(x =>
                {
                    str = string.Concat(str, BuildParamenter(x.Key, x.Value));
                });
            return str;
        }
    }

    internal class EddaLogMessage
    {
        public int code { get; set; }
        public string Message { get; set; }
    }
}