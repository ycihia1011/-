﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace InsuranceWeb.Commons
{
    public static class ServiceDoname
    {
        /// <summary>
        /// 取得現在的Doname
        /// </summary>
        /// <param name=""></param>
        /// <returns>DonameString</returns>
        /// 
        public static string getDonameString()
        {
            string Doname = System.Web.HttpContext.Current.Request.Url.Host != "localhost"? System.Web.HttpContext.Current.Request.Url.Host : System.Web.HttpContext.Current.Request.Url.Authority;

            return Doname;
        }

        /// <summary>
        /// 測試環境的Doname
        /// </summary>
        /// <param name=""></param>
        /// <returns>Doname Array</returns>
        /// 
        public static List<string> testDoname()
        {
            List<string> dn = new List<string>();
            dn.Add("test-online.skl.com.tw");
            dn.Add("localhost:44301");
            dn.Add("localhost:44303");
            dn.Add("localhost:44302");

            return dn;
        }

        /// <summary>
        /// 比對測試環境Doname
        /// </summary>
        /// <param name=""></param>
        /// <returns>True or False</returns>
        /// 
        public static bool checkTestDoname()
        {
            return testDoname().Contains(getDonameString().ToLower());
        }
    }
}
