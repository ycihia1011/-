﻿namespace InsuranceWeb.Commons
{
    using System;
    using System.Linq;
    using System.Collections.Generic;

    public static class DataTableHelper
    {
        #region 將List轉為DataTable + DataTable ListToDataTable<TResult>(this IEnumerable<TResult> listValue)
        /// <summary>
        /// 將List轉為DataTable
        /// </summary>
        /// <param name="tableName">資料庫名稱,若沒寫則用T的名稱</param>
        /// <returns></returns>
        public static System.Data.DataTable ListToDataTable<TResult>(this IEnumerable<TResult> listValue, string tableName) where TResult : class, new()
        {
            var dataTable = new System.Data.DataTable(tableName);
            //Get all the properties
            var props = typeof(TResult).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            foreach (var prop in props)
            {
                var propType = prop.PropertyType.Name.ToLower();
                //Setting column names as Property names
                switch(propType)
                {
                    case "int32":
                        dataTable.Columns.Add(prop.Name,typeof(Int32));
                        break;
                    case "datetime":
                        dataTable.Columns.Add(prop.Name,typeof(DateTime));
                        break;
                    default:
                        dataTable.Columns.Add(prop.Name);
                        break;
                }
            }
            foreach (var item in listValue)
            {
                var values = new object[props.Length];
                for (var i = 0; i < props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
        #endregion
        #region  將DataTable轉為List + List<TResult> DataTableToList<TResult>(this System.Data.DataTable dataTableValue)
        /// <summary>
        /// 將DataTable轉為List
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="dataTableValue"></param>
        /// <returns></returns>
        public static List<TResult> DataTableToList<TResult>(this System.Data.DataTable dataTableValue) where TResult : class, new()
        {
            //建立一個回傳用的 List<TResult>
            var resultList = new List<TResult>();

            //取得映射型別
            var type = typeof(TResult);

            //儲存 DataTable 的欄位名稱
            var prList = type.GetProperties().Where(item => dataTableValue.Columns.IndexOf(item.Name) != -1).ToList();

            //逐筆將 DataTable 的值新增到 List<TResult> 中
            foreach (System.Data.DataRow item in dataTableValue.Rows)
            {
                TResult tr = new TResult();

                foreach (System.Reflection.PropertyInfo item1 in prList)
                {
                    if (item[item1.Name] != DBNull.Value)
                        item1.SetValue(tr, item[item1.Name], null);
                }
                resultList.Add(tr);
            }
            return resultList;
        }

		/// <summary>用 DbColumnAttribute 來對應 database column 到 domain model</summary>
		/// <typeparam name="ModelT">Domain Model Type</typeparam>
		/// <param name="dbDataTable">Database DataTable</param>
		/// <returns>null for null datatable / list of models</returns>
		public static List<ModelT> MapToModelList<ModelT>(this System.Data.DataTable dbDataTable) where ModelT : class, new()
		{
			if (dbDataTable == null)
				return null;

			// 建立一個回傳用的 List<TResult>
			var dataList = new List<ModelT>();

			if (dbDataTable.Rows == null || dbDataTable.Rows.Count < 1)
				return dataList;
			
			// 取得映射型別
			var type = typeof(ModelT);

			// 逐筆將 DataTable 的值新增到 List<ModelT> 中
			foreach (System.Data.DataRow dr in dbDataTable.Rows)
			{
				ModelT model = new ModelT();

				List<DbColumnAttribute> dbColumns = new List<DbColumnAttribute>();
				foreach (var property in type.GetProperties())
				{
					var attributes = property.GetCustomAttributes(false);
					var dbColAttribute = attributes.FirstOrDefault(a => a.GetType() == typeof(DbColumnAttribute)) as DbColumnAttribute;
					// 有 db column attribute 與在 datatable 中有此 column 才寫入
					if (dbColAttribute != null && dbDataTable.Columns.Contains(dbColAttribute.Name))
					{
						dbColumns.Add(dbColAttribute);
						property.SetValue(model, dr[dbColAttribute.Name], null);
					}
				}

				dataList.Add(model);
			}

			return dataList;
		}
        #endregion
        public static decimal ConvertToDecimalPlus(this object value)
        {
            return value == null ? 0 : Convert.ToDecimal(value);
        }
        public static double ConvertToDoublePlus(this object value)
        {
            return value == null ? 0 : Convert.ToDouble(value);
        }
        public static double ConvertToIntPlus(this object value)
        {
            return value == null ? 0 : Convert.ToInt32(value);
        }
	}
}
