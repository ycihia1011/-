﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Web.Mvc;

namespace InsuranceWeb.Commons
{
	public static class Helper
	{
		/// <summary>
		/// 將Object DateTime轉換為DateTime
		/// </summary>
		/// <param name="obj">Object DateTime</param>
		/// <returns>DateTime</returns>
		public static DateTime GetParseDateTime(this object obj)
		{
			DateTime dtTmp;
			if (!DateTime.TryParseExact(obj.ToString(), new string[] { "yyyy/MM/dd", "yyyy-MM-dd", "yyyy-MM-dd+HH:mm" }, null, System.Globalization.DateTimeStyles.None, out dtTmp))
			{
				return new DateTime();
			}
			return dtTmp;
		}

		/// <summary>
		/// 計算投保年齡，以系統日期為基礎日
		/// </summary>
		/// <param name="dtBirthDay">生日日期</param>
		/// <returns>回傳年齡資料</returns>
		public static int CalcuInsureAge(DateTime dtBirthDay)
		{
			return CalcuInsureAge(dtBirthDay, System.DateTime.Now);
		}

		/// <summary>
		/// 計算投保年齡
		/// </summary>
		/// <param name="dtBirthDay">生日日期</param>
		/// <param name="dtBaseDay">設定計算依據的基礎日(一般為 投保日 AccureDate)</param>
		/// <returns>回傳年齡資料</returns>
		public static int CalcuInsureAge(DateTime dtBirthDay, DateTime dtBaseDay)
		{
			//計算投保年齡
			int iY = dtBaseDay.Year - dtBirthDay.Year;
			int iM = dtBaseDay.Month - dtBirthDay.Month;
			int iD = dtBaseDay.Day - dtBirthDay.Day;

			if ((iM > 6) || ((iM == 6) && (iD > 0)))
				iY++;
			else if ((iM < -6) || ((iM == -6) && (iD < 1)))
				iY--;

			return Math.Max(iY, 0);

		}
		/// <summary>
		/// 計算投保年齡
		/// </summary>
		/// <param name="dtBirthDay">生日日期</param>
		/// <param name="dtBaseDay">設定計算依據的基礎日(一般為 投保日 AccureDate)</param>
		/// <returns>回傳年齡資料</returns>
		public static int CalcuInsureAge2(DateTime dtBirthDay, DateTime dtBaseDay)
		{
			//計算投保年齡
			DateTime dt = dtBaseDay.AddDays(-dtBirthDay.Day).AddMonths(-dtBirthDay.Month);
			int iY = dt.Year - dtBirthDay.Year;
			int iM = dt.Month;
			if (iM >= 6)
				iY++;
			// else if ((iM < -6) || ((iM == -6) && (iD < 1)))
			//     iY--;

			return Math.Max(iY, 0);

		}

		/// <summary>
		/// 計算投保年齡 加計當天
		/// </summary>
		/// <param name="dtBirthDay">生日日期</param>
		/// <param name="dtBaseDay">設定計算依據的基礎日(一般為 投保日 AccureDate)</param>
		/// <returns>回傳年齡資料</returns>
		public static int CalcuInsureAge3(DateTime dtBirthDay, DateTime dtBaseDay)
		{
			//計算投保年齡
			int iY = dtBaseDay.Year - dtBirthDay.Year;
			int iM = dtBaseDay.Month - dtBirthDay.Month;
			int iD = dtBaseDay.Day - dtBirthDay.Day;

			if ((iM > 6) || ((iM == 6) && (iD >= 0)))
				iY++;
			else if ((iM < -6) || ((iM == -6) && (iD < 0)))
				iY--;

			return Math.Max(iY, 0);

		}

		/// <summary>
		/// 計算足歲年齡
		/// </summary>
		/// <param name="dtBirthDay">生日日期</param>
		/// <param name="dtBaseDay">設定計算依據的基礎日</param>
		/// <returns>回傳年齡資料</returns>
		public static int CalcuFullAge(DateTime dtBirthDay, DateTime dtBaseDay)
		{
			int iY = dtBaseDay.Year - dtBirthDay.Year;
			if (dtBaseDay < dtBirthDay.AddYears(iY))
			{
				iY--;
			}
			return iY;
		}

		public static T DeserializeJson<T>(string jsonString) where T : class
		{
			try
			{
				byte[] jsonBytes = Encoding.UTF8.GetBytes(jsonString);

				using (var ms = new MemoryStream(jsonBytes))
				using (var sr = new StreamReader(ms))
				{
					using (var reader = new Newtonsoft.Json.JsonTextReader(sr))
					{
						var serializer = new Newtonsoft.Json.JsonSerializer()
						{
							MissingMemberHandling = Newtonsoft.Json.MissingMemberHandling.Ignore,
							NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore
						};

						return serializer.Deserialize<T>(reader);
					}
				}
			}
			catch
			{
				return null;
			}
		}

		public static string TravelPlanCode = "66020";
		public static string AccidentPlanCode = "20511";
		public static string IGoingPlanCode = "20520";
		public static string HealthPlanCode = "KAA01";
		public static string LifePlanCode = "LAA01";
		public static string AnnuityPlanCode = "EZA99";
		public static string EnterpriseTravelPlanCode = "62020";
		public static string SevenPlusPlanCode = "5KA07";
		public static string UpCashPlanCode = "UCA99";
		public static string ICanPlanCode = "20530";

		/// <summary>取 LOCAL URL, 不合法的 URL 則回 null</summary>
		/// <param name="link">要返回的Url</param>
		/// <param name="localUri">Request.Url(當前的請求URL)</param>
		/// <returns></returns>
		public static string GetLocalUrl(string link, Uri localUri)
		{
			try
			{
				Uri uriLink;

				if (!Uri.TryCreate(link, UriKind.RelativeOrAbsolute, out uriLink))
					return null;

				if (uriLink.IsAbsoluteUri && Uri.IsWellFormedUriString(link, UriKind.Absolute))
				{
					if (localUri.Host == uriLink.Host)
					{
						string rel = uriLink.LocalPath + uriLink.Query;

						return rel;
					}

					return null;
				}

				if (Uri.IsWellFormedUriString(link, UriKind.Relative))
				{
					var fullUrl = "/" + link.TrimStart('/');

					return fullUrl;
				}

				return null;
			}
			catch
			{
				return null;
			}
		}

		/// <summary>
		/// 讀取 Cache 資料
		/// </summary>
		/// <param name="cacheId">Cache名稱</param>
		/// <returns></returns>
		public static object GetCache(string cacheId)
		{
			return System.Web.HttpRuntime.Cache.Get(cacheId);
		}
		/// <summary>
		/// 寫入 Cache 資料 ( 預設 3600 秒 )
		/// </summary>
		/// <param name="cacheId">Cache存入名稱</param>
		/// <param name="cacheValue">Cache存入值</param>
		public static void SetCache(string cacheId, object cacheValue)
		{
			if (cacheValue != null)
			{
				System.Web.HttpRuntime.Cache.Insert(
					cacheId,
					cacheValue,
					null,
					System.Web.Caching.Cache.NoAbsoluteExpiration,
					new TimeSpan(0, 0, 3600),
					System.Web.Caching.CacheItemPriority.High,
					null);
			}
		}

		/// <summary>config file 的 app setting key 是否啟用中</summary>
		/// <param name="appSettingKey"></param>
		/// <returns></returns>
		public static bool IsDateTimePeriodActive(string appSettingKey)
		{
			if (string.IsNullOrWhiteSpace(appSettingKey))
				return false;

			string period = ConfigurationManager.AppSettings[appSettingKey];

			if (string.IsNullOrWhiteSpace(period))
				return false;

			var p = period.Split('~');
			if (p == null || p.Length < 1)
				return false;

			DateTime start = DateTime.MinValue;
			DateTime end = DateTime.MaxValue;

			DateTime tmp;
			if (!string.IsNullOrWhiteSpace(p[0]))
			{
				if (DateTime.TryParse(p[0], out tmp))
					start = tmp;
			}

			if (p.Length > 1 && !string.IsNullOrWhiteSpace(p[1]))
			{
				if (DateTime.TryParse(p[1], out tmp))
					end = tmp;
			}

			var now = DateTime.Now;

			return start <= now && end >= now;
		}

		/// <summary>
		/// 取得信用卡銀行清單
		/// </summary>
		/// <returns></returns>
		public static List<SelectListItem> GetBankList()
		{
			return new List<SelectListItem>()
			{
                #region 信用卡銀行
                new SelectListItem()
				{
					Value = "004",
					Text = "(004)台灣銀行"
				},
				new SelectListItem()
				{
					Value = "005",
					Text = "(005)台灣土地銀行"
				},
				new SelectListItem()
				{
					Value = "006",
					Text = "(006)合作金庫"
				},
				new SelectListItem()
				{
					Value = "007",
					Text = "(007)第一銀行"
				},
				new SelectListItem()
				{
					Value = "008",
					Text = "(008)華南銀行"
				},
				new SelectListItem()
				{
					Value = "009",
					Text = "(009)彰化銀行"
				},
				new SelectListItem()
				{
					Value = "011",
					Text = "(011)上海銀行"
				},
				new SelectListItem()
				{
					Value = "012",
					Text = "(012)台北富邦銀行"
				},
				new SelectListItem()
				{
					Value = "013",
					Text = "(013)國泰世華"
				},
				new SelectListItem()
				{
					Value = "016",
					Text = "(016)高雄銀行"
				},
				new SelectListItem()
				{
					Value = "017",
					Text = "(017)兆豐銀行"
				},
                new SelectListItem()
                {
                    Value = "021",
                    Text = "(021)花旗銀行"
                },
                new SelectListItem()
				{
					Value = "048",
					Text = "(048)王道銀行"
				},
				new SelectListItem()
				{
					Value = "050",
					Text = "(050)台灣企銀"
				},
				new SelectListItem()
				{
					Value = "052",
					Text = "(052)渣打銀行"
				},
				new SelectListItem()
				{
					Value = "053",
					Text = "(053)台中銀行"
				},
				new SelectListItem()
				{
					Value = "081",
					Text = "(081)匯豐(台灣)"
				},
				new SelectListItem()
				{
					Value = "102",
					Text = "(102)華泰銀行"
				},
				new SelectListItem()
				{
					Value = "103",
					Text = "(103)新光銀行"
				},
				new SelectListItem()
				{
					Value = "108",
					Text = "(108)陽信銀行"
				},
				new SelectListItem()
				{
					Value = "147",
					Text = "(147)三信銀行"
				},
                new SelectListItem()
                {
                    Value = "700",
                    Text = "(700)中華郵政公司"
                },
                new SelectListItem()
				{
					Value = "803",
					Text = "(803)聯邦銀行"
				},
				new SelectListItem()
				{
					Value = "805",
					Text = "(805)遠東銀行"
				},
				new SelectListItem()
				{
					Value = "806",
					Text = "(806)元大銀行"
				},
				new SelectListItem()
				{
					Value = "807",
					Text = "(807)永豐銀行"
				},
				new SelectListItem()
				{
					Value = "808",
					Text = "(808)玉山銀行"
				},
				new SelectListItem()
				{
					Value = "809",
					Text = "(809)凱基銀行"
				},
				new SelectListItem()
				{
					Value = "810",
					Text = "(810)星展銀行(台灣)"
				},
				new SelectListItem()
				{
					Value = "812",
					Text = "(812)台新銀行"
				},
				//new SelectListItem()
				//{
				//	Value = "814",
				//	Text = "(814)大眾銀行"
				//},
				new SelectListItem()
				{
					Value = "815",
					Text = "(815)日盛銀行"
				},
				new SelectListItem()
				{
					Value = "816",
					Text = "(816)安泰銀行"
				},
				new SelectListItem()
				{
					Value = "822",
					Text = "(822)中國信託"
				},
				new SelectListItem()
				{
					Value = "9990",
					Text = "永旺信用卡"
				},
				new SelectListItem()
				{
					Value = "9991",
					Text = "樂天信用卡"
				},
                #endregion
            };
		}

		/// <summary>
		/// 限制字數，後方加入...
		/// </summary>
		/// <param name="str">字串</param>
		/// <param name="wordCount">字數</param>
		/// <returns></returns>
		public static string LimitWordCount(this string str, int? wordCount)
		{
			if (string.IsNullOrWhiteSpace(str) || !wordCount.HasValue)
				return str;

			if (str.Length < wordCount)
				return str;

			return string.Format("{0}...", str.Substring(0, wordCount.Value));
		}

		/// <summary>
		/// 帳戶遮罩
		/// </summary>
		/// <param name="str">字串</param>
		/// <param name="slength">開始遮罩位置</param>
		/// <param name="markcount">遮罩幾個字元</param>
		/// <returns></returns>
		public static string AccountMask(string str, int slength, int markcount)
		{
			int strlength = str.Length;
			int minlength = slength + markcount - 1;

			if (string.IsNullOrWhiteSpace(str))
			{
				return str;
			}
			if (strlength < minlength)
			{
				if (strlength < slength)
				{
					return str;
				}
				minlength = strlength;
			}
			char[] strarray = str.ToCharArray();
			for (int i = slength - 1; i < minlength; i++)
			{
				strarray[i] = '*';
			}
			return string.Join("", strarray);
		}

		/// <summary>用台灣發行的證號判斷性別 (M/F)</summary>
		/// <param name="idNo">證號</param>
		/// <returns>M-男, F-女, 空-無法判別</returns>
		public static string GetGenderFromIdNo(string idNo)
		{
			if (string.IsNullOrWhiteSpace(idNo) || idNo.Length < 2)
				return string.Empty;

			var idGenderCode = idNo.Substring(1, 1);
			string[] maleIdCode = new string[] { "1", "A", "C" };
			if (maleIdCode.Contains(idGenderCode))
				return "M";

			string[] femaleIdCode = new string[] { "2", "B", "D" };
			if (femaleIdCode.Contains(idGenderCode))
				return "F";

			return string.Empty;
		}
    }
}