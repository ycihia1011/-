﻿namespace InsuranceWeb.Commons.DisplayMessage
{
	public class WebMessage
	{
		public class ErrorMessage
		{
			/// <summary>系統更新中</summary>
			public const string UnderConstruction = "親愛的客戶，感謝您對網路投保的支持，由於目前系統更新，請您稍候再試。造成不便我們深感抱歉，再次感謝您的惠顧";

			/// <summary>身分證(含外籍人士身分證)格式錯誤</summary>
			public const string InvalidIdNumber = "請確認身分證字號格式正確";

			/// <summary>不受理外籍人士</summary>
			public const string NoForeigner = "親愛的客戶謝謝您的申購，本公司不受理外籍人士投保，很抱歉您無法於本網站進行投保動作。煩請另洽新光人壽服務人員詢問其他相關商品，造成您的不便我們深感抱歉，再次感謝您的惠顧。";

			/// <summary>session逾時</summary>
			public const string SessionExpired = "親愛的客戶，您好！操作已逾20分鐘，為保障您資料安全，請重新您的投保流程";

            /// <summary>登入逾時</summary>
            public const string UserDataExpired = "親愛的客戶，您好！系統逾時，請重新登入後再投保";

            /// <summary>被保人超過受理投保年齡限制</summary>
            public const string AgeOutOfRange = "親愛的客戶謝謝您的申購保險，此交易因您已超過受理投保年齡限制，很抱歉您無法於本網站進行投保，請再次確認資料，請修正投保資料以符合規定，或另洽新光人壽服務人員詢問相關保險商品購買事宜，造成您的不便我們深感抱歉，再次感謝您的惠顧";

			/// <summary>被保子女超過受理投保年齡限制(%ChildName% 為姓名, 須取代)</summary>
			public const string ChildAgeOutOfRange = "親愛的客戶謝謝您的申購，因貴子女%ChildName%超過受理年齡，很抱歉您無法於本網站進行投保動作。煩請另洽新光人壽服務人員詢問其他相關商品，造成您的不便我們深感抱歉，再次感謝您的惠顧。";

			/// <summary>黑名單</summary>
			public const string BlackList = "親愛的客戶您好!感謝您的申請投保，因本公司網路投保本商品申請資格限制，以致您無法於本網站進行投保。如有購買相關商品需求，建議您可洽詢新光人壽服務人員或撥打0800-031115客服專線，我們將竭誠為您服務，造成您的不便深感致歉，並感謝您的惠顧";

			/// <summary>訂單作業失敗</summary>
			public const string OrderCreateFailed = "無法產生訂單";

			/// <summary>付款狀態未明確</summary>
			public const string UndeterminedPaymentResult = "欲查詢訂單狀態，請至客戶服務中心 > 保單管理 > 保單/待繳費保單資料";
		}
	}
}