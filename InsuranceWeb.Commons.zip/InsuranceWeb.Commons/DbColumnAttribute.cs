﻿using System;

namespace InsuranceWeb.Commons
{
	public class DbColumnAttribute : Attribute
	{
		public string Name { get; private set; }

		public DbColumnAttribute(string name)
		{
			this.Name = name;
		}
	}
}
