﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace InsuranceWeb.Commons
{
	public class DataModelHelper
	{
		/// <summary>比對資料後回傳異動過的欄位</summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="newData">異動後資料</param>
		/// <param name="oldData">原始資料</param>
		/// <param name="modifiedMessage">異動欄位訊息 Name: Before = [x], After = [y]</param>
		/// <param name="propToCheck">只要檢查的欄位, 不傳則檢察 T 全部欄位</param>
		/// <returns></returns>
		public static IEnumerable<string> GetModifiedColumn<T>(T newData, T oldData, out string[] modifiedMessage, params string[] propToCheck) where T : class
		{
			Type t = typeof(T);

			var mod = new List<string>();
			var fields = new List<string>();

			PropertyInfo[] props;
			if (propToCheck != null && propToCheck.Length > 0)
			{
				var pList = new List<PropertyInfo>();
				foreach(var p in propToCheck)
				{
					pList.Add(t.GetProperty(p));
				}
				props = pList.ToArray();
			}
			else
				props = t.GetProperties(BindingFlags.Public | BindingFlags.Instance);

			foreach (var p in props)
			{
				var isEqual = true;
				var nVal = p.GetValue(newData);
				var oVal = p.GetValue(oldData);

				var isComparable = typeof(IComparable).IsAssignableFrom(p.GetType());
				if (nVal == null && oVal == null)
				{
					// both nulls, consider not changed
					isEqual = true;
				}
				else if (nVal == null)
				{
					isEqual = false;
				}
				else if (oVal == null)
				{
					isEqual = false;
				}
				else if (isComparable)
				{
					// primative type is comparable
					var cmp = oVal as IComparable;
					if (cmp != null)
						isEqual = cmp.CompareTo(nVal) == 0;
				}
				else if (oVal.Equals(nVal))
				{
					// using equals
					isEqual = true;
				}
				else if (nVal == oVal)
				{
					isEqual = true;
				}
				else
					isEqual = false;

				if (!isEqual)
				{
					mod.Add(p.Name + ": Before = [" + oVal + "], After = [" + nVal + "]");
					fields.Add(p.Name);
				}
			}

			modifiedMessage = mod.ToArray();
			
			return fields.ToArray();
		}
	}
}