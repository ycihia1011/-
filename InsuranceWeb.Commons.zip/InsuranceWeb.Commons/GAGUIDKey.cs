﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace InsuranceWeb.Commons
{
    public static class GAGUIDKey
    {

        /// <summary>
        /// 自動生成GUID Key供GA Ecommerce Tracking使用
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        /// 
        public static Guid setGAGUID()
        {
            Guid g;
            // Create and display the value of two GUIDs.
            g = Guid.NewGuid();

            return g;
        }

        /// <summary>
        /// 產生guid session
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        ///
        public static void setGUIDSession()
        {
            String gNo = setGAGUID().ToString();
            HttpContext.Current.Session["GAEcommerceId"] = gNo;

        }

        /// <summary>
        /// 取得guid session
        /// </summary>
        /// <param name=""></param>
        /// <returns>session guid</returns>
        ///
        public static String getGUIDSession()
        {

            if (HttpContext.Current.Session["GAEcommerceId"] == null)
            {   
                setGUIDSession();
            }

            return (string)(HttpContext.Current.Session["GAEcommerceId"]);
        }


        /// <summary>
        /// 清除guid session
        /// </summary>
        /// <param name=""></param>
        /// <returns>session guid</returns>
        ///

        public static void cleanGAID()
        {
            HttpContext.Current.Session.Remove("GAEcommerceId");
        }
    }
}
