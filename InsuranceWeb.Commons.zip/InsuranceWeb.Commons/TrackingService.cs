﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceWeb.Commons
{
	public class TrackingService
	{
		public static class GoogleTracking
		{
			public static class Desktop
			{
				public class ECommerce
				{
					public const string EnterpriseTravel = "";

					public const string Accident = "";

					public const string EzCash = "";

					public const string NewHealth = "";

					public const string ICan = "";

					public const string IGoing = "";

					public const string IWell = "";

					public const string MyWay = "";

					public const string SevenPlus = "";

					public const string Travel = "Travel";

					public const string UpCash = "";
				}
			}

			public class Mobile
			{

			}
		}
	}
}