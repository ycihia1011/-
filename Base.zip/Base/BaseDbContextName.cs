﻿namespace InsuranceWeb.EFRepository
{
	internal enum BaseDbContextName
    {
        InsuranceWebEntities,
        InsuranceWebAdminEntities,
        SKLMemberShipEntities,
        SKLwebdbEntities,
        MultiFunctionEntities
    }
}
