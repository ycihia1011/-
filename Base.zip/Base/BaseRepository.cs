﻿namespace InsuranceWeb.Repository
{
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Text;

    [Serializable]
    public class BaseRepository
    {
        private DbConnection dbConn = null;

        public StringBuilder sbSql = new StringBuilder(1000);

        /// <summary>
        /// 創建SQL連接類
        /// </summary>
        /// <param name="conn">要連接的資料庫</param>
        /// <returns>DbConnection</returns>
        private DbConnection CreatedbConn(string connName)
        {
            return new SqlConnection(GetConnectionString(connName));
        }
        /// <summary>
        /// 取於設定值中的連線字串含解密
        /// </summary>
        /// <param name="connName">要連接的資料庫</param>
        /// <returns></returns>
        public string GetConnectionString(string connName)
        {
            var conn = ConfigurationManager.ConnectionStrings[connName].ConnectionString;
            var csb = new SqlConnectionStringBuilder(conn)
            {
                Password = SecureStringToString(GetDeHexString(Model.DataBaseConnection.ConnectionHexDictCurrent()[connName]))
            };
            return csb.ToString();
        }

        /// <summary>
        /// 增刪改返回受影響行數
        /// </summary>
        /// <param name="sql">Sql語法</param>
        /// <param name="connName">連接的數據庫設定檔名稱</param>
        /// <param name="parameters">可變SQL參數</param>
        /// <returns></returns>
        protected int ExecuteNonQuery(string sql, string connName, params SqlParameter[] parameters)
        {
            if (string.IsNullOrEmpty(sql)
                || string.IsNullOrEmpty(connName)) return -1;
            using (dbConn = CreatedbConn(connName))
            {
                dbConn.Open();
                using (var cmd = dbConn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.CommandType = CommandType.Text;
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// 返回一行一列的數據
        /// </summary>
        /// <param name="sql">Sql語法</param>
        /// <param name="connName">連接的數據庫設定檔名稱</param>
        /// <param name="parameters">可變SQL參數</param>
        /// <returns></returns>
        protected object ExecuteScalar(string sql, string connName, params SqlParameter[] parameters)
        {
            if (string.IsNullOrEmpty(sql)
                || string.IsNullOrEmpty(connName)) return null;
            using (dbConn = CreatedbConn(connName))
            {
                dbConn.Open();
                using (var cmd = dbConn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.CommandType = CommandType.Text;
                    return cmd.ExecuteScalar() ?? string.Empty;
                }
            }
        }

        /// <summary>
        /// 返回整個資料結果集 + DataTable ExecuteDataTable
        /// </summary>
        /// <param name="sql">Sql語法</param>
        /// <param name="connName">連接的數據庫設定檔名稱</param>
        /// <param name="parameters">可變SQL參數</param>
        /// <returns></returns>
        public DataTable ExecuteDataTable(string sql, string connName, params SqlParameter[] parameters)
        {
            if (string.IsNullOrEmpty(sql)
                || string.IsNullOrEmpty(connName)) return null;

            using (dbConn = CreatedbConn(connName))
            {
                dbConn.Open();
                using (var cmd = dbConn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.CommandType = CommandType.Text;
                    var dbFactory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                    var adapter = dbFactory.CreateDataAdapter();
                    adapter.SelectCommand = cmd;
                    var ds = new DataSet();
                    adapter.Fill(ds);
                    return ds.Tables[0];
                }
            }
        }

        /// <summary>
        /// 複製多筆資料到資料庫
        /// </summary>
        /// <param name="connName">連接的數據庫設定檔名稱</param>
        /// <param name="dt">要複製的Table</param>
        /// <returns></returns>
        protected bool BulkCopyData(string connName, DataTable dt)
        {
            using (dbConn = CreatedbConn(connName))
            {
                dbConn.Open();
                var bulkcopy = new SqlBulkCopy(dbConn as SqlConnection) { DestinationTableName = dt.TableName };
                try
                {
                    bulkcopy.WriteToServer(dt);
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
            return false;
        }

        private static SecureString GetDeHexString(string hexStr)
        {
            var oriPwd = string.Empty;
            var hexArr = hexStr.Split(' ');

            foreach (string hex in hexArr)
            {
                int value = Convert.ToInt32(hex, 16);
                string stringValue = Char.ConvertFromUtf32(value);
                char charValue = (char)value;
                oriPwd += stringValue;
            }
            return GenSecureString(oriPwd);
        }

        private static SecureString GenSecureString(string source)
        {
            var sourceArr = source.ToCharArray();
            var securePwd = new SecureString();
            for (int i = 0; i < sourceArr.Length; i++)
                securePwd.AppendChar(sourceArr[i]);
            return securePwd;
        }
        private static String SecureStringToString(SecureString value)
        {
            IntPtr valuePtr = Marshal.SecureStringToGlobalAllocUnicode(value);
            var sb = new System.Text.StringBuilder(1000);
            try
            {

                for (Int32 i = 0; i < value.Length; i++)
                {
                    // multiply 2 because Unicode chars are 2 bytes wide
                    Char ch = (Char)Marshal.ReadInt16(valuePtr, i * 2);
                    // do something with each char
                    sb.Append(ch);
                }

                return sb.ToString();
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(valuePtr);
            }
        }
    }
}