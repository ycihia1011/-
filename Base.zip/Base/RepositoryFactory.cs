﻿namespace InsuranceWeb.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Reflection;
    using Repository;

    public class RepositoryFactory<T>
    {
        private static T instance;
        /// <summary>
        /// Reflection創建類
        /// </summary>
        /// <returns></returns>
        public static T GetInstance()
        {
            if (instance != null) return instance;
            var ass = Assembly.Load("InsuranceWebAdmin.Repository").GetTypes()
                .Where(s => s.FullName.Contains(typeof(T).Name))
                .FirstOrDefault();
            instance = (T)Activator.CreateInstance(ass);//as會驗證型別,所以直接用強轉型
            return instance;
        }
    }
}
