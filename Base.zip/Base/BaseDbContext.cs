﻿using System.Data.Entity;

namespace InsuranceWeb.EFRepository
{
	internal class BaseDbContext:DbContext
    {
        internal BaseDbContext(string nameOrConnectionString,bool isConnectionString = false) 
            : base(isConnectionString ? nameOrConnectionString : "name=" + nameOrConnectionString)
        {
            var instance = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
        }
    }
}
