﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Security;

namespace InsuranceWeb.EFRepository
{
    public class BaseDbRepository<T> where T : class
    {
        private readonly DbContext _db;
        private readonly DbSet<T> _dbSet;

        #region 1.0 構造函數初始化

        /// <summary>
        /// 1.0 構造函數初始化
        /// </summary>
        public BaseDbRepository(string nameOrConnectionString)
        {
            //. 設定EF連接資訊
            _db = new BaseDbContext(nameOrConnectionString);
            //. 取出EF用連線字串
            var conn = ConfigurationManager.ConnectionStrings[nameOrConnectionString].ConnectionString;
            var entityCnxStringBuilder = new System.Data.Entity.Core.EntityClient.EntityConnectionStringBuilder(conn);
            //. 替換EF連線字串之密碼
            var sqlCnxStringBuilder = new SqlConnectionStringBuilder(entityCnxStringBuilder.ProviderConnectionString)
            {
                Password = SecureStringToString(GetDeHexString(Model.DataBaseConnection.ConnectionHexDictCurrent()[nameOrConnectionString]))
            };
            //. 將此次EF連接資訊密碼替換
            _db.Database.Connection.ConnectionString = sqlCnxStringBuilder.ConnectionString;
            _dbSet = _db.Set<T>();
            if (Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["EFTestMode"]))
                System.Data.Entity.Infrastructure.Interception.DbInterception.Add(new EFIntercepterLogging());
        }

        #endregion 1.0 構造函數初始化

        #region 2.0 獲取資料集

        /// <summary>
        /// 2.0 獲取資料集
        /// </summary>
        /// <param name="whereExpression">查詢條件</param>
        /// <returns>List集合</returns>
        public List<T> Get(Expression<Func<T, bool>> whereExpression)
        {
            return _dbSet.AsNoTracking<T>().Where(whereExpression).ToList();
        }

        public IQueryable<T> Where(Expression<Func<T, bool>> whereExpression)
        {
            return _dbSet.AsNoTracking<T>().Where(whereExpression);
        }

        #endregion 2.0 獲取資料集

        /// <summary>
        ///
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalCount"></param>
        /// <returns></returns>
        public List<T> GetPageList(Expression<Func<T, bool>> whereExpression, int pageIndex, int pageSize,
            out int totalCount)
        {
            totalCount = _dbSet.Count();
            return _dbSet.Where(whereExpression).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

        #region 3.0 新增實體

        /// <summary>
        /// 3.0 新增實體
        /// </summary>
        /// <param name="model">要新增的實體對象</param>
        public void Add(T model)
        {
            if (model == null
                || string.IsNullOrEmpty(_db.Database.Connection.ConnectionString)) return;
            
            _dbSet.Add(model);
        }

        #endregion 3.0 新增實體

        #region 4.0 刪除實體

        /// <summary>
        /// 4.0 刪除實體
        /// </summary>
        /// <param name="model">要刪除的實體</param>
        /// <param name="isAddedContext">是否已附加到上下文中</param>
        public void Del(T model, bool isAddedContext)
        {
            if (!isAddedContext) _dbSet.Attach(model);
            _dbSet.Remove(model);
        }

        #endregion 4.0 刪除實體

        #region 4.1 帶條件刪除 + void DelWhere(Expression<Func<T, bool>> where)

        /// <summary>
        /// 4.1 刪除實體 By 條件
        /// </summary>
        /// <param name="where">要刪除的條件</param>
        public void DelWhere(Expression<Func<T, bool>> where)
        {
            _dbSet.RemoveRange(_dbSet.Where(where));
        }

        #endregion 4.1 帶條件刪除 + void DelWhere(Expression<Func<T, bool>> where)

        #region 5.0 更新實體

        /// <summary>
        /// 5.0 更新實體
        /// </summary>
        /// <param name="model">要更新的實體</param>
        /// <param name="proNames">要更新的實體參數名稱</param>
        public void Edit(T model, params string[] proNames)
        {
            var entry = _db.Entry(model);
            entry.State = EntityState.Unchanged;
            foreach (var proName in proNames) entry.Property(proName).IsModified = true;
            _db.Configuration.ValidateOnSaveEnabled = false;
        }

        #endregion 5.0 更新實體

        #region 6.0 執行SQL語法

        /// <summary>
        /// 6.0 執行SQL語法(返回查詢資料)
        /// </summary>
        /// <typeparam name="TResult">執行的返回值類型</typeparam>
        /// <param name="sqlStr">執行的SQL語句</param>
        /// <param name="parameters">執行的SQL變量</param>
        /// <returns>List集合</returns>
        public List<TResult> RunSql<TResult>(string sqlStr, params object[] parameters)
        {
            return _db.Database.SqlQuery<TResult>(sqlStr, parameters).ToList();
        }

        /// <summary>
        /// 6.0 執行SQL語法(對資料做更動)
        /// </summary>
        /// <typeparam name="TResult">執行的返回值類型</typeparam>
        /// <param name="sqlStr">執行的SQL語句</param>
        /// <param name="parameters">執行的SQL變量</param>
        /// <returns>List集合</returns>
        public int ExecuteNoneQuery(string sqlStr, params object[] parameters)
        {
            return _db.Database.ExecuteSqlCommand(sqlStr, parameters);
        }

        #endregion 6.0 執行SQL語法

        #region 7.0 保存 + int SaveChanges()

        /// <summary>
        /// 7.0 保存
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, object> SaveChanges()
        {
            try
            {
                var res = _db.SaveChanges();
                return res >= 0
                ? new Dictionary<int, object>() { { 1, "ok" } }
                : new Dictionary<int, object>() { { -1, "fail" } };
            }
            catch (DbEntityValidationException ex)
            {
                var entityError = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                var getFullMessage = string.Join("; ", entityError);
                var exceptionMessage = string.Concat(ex.Message, " errors are: ", getFullMessage);
                this.SendErrorMail("DbEntityValidationException", exceptionMessage, new List<string> { "skek1008@skl.com.tw" });
                return new Dictionary<int, object>()
                {
                    { -1, exceptionMessage }
                };
            }
        }

        public int TransActionSaveChanges()
        {
            return _db.SaveChanges();
        }

        #endregion 7.0 保存 + int SaveChanges()

        /// <summary>
        /// 寄送錯誤信件
        /// </summary>
        /// <param name="mailSubject">信件主旨</param>
        /// <param name="mailMessage">信件內容</param>
        /// <param name="receiveUsers">收信人</param>
        public virtual void SendErrorMail(string mailSubject, string mailMessage, List<string> receiveUsers)
        {
            MailClass.SendErrorMail(mailSubject, mailMessage, receiveUsers);
        }

        /// <summary>
        /// BeginTransaction
        /// </summary>
        /// <param name="action">新增實體 </param>
        public void TransAction(Action action)
        {
            using (var dbContextTransaction = _db.Database.BeginTransaction())
            {
                try
                {
                    _db.Configuration.EnsureTransactionsForFunctionsAndCommands = true;
                    action();
                    dbContextTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                }
            }
        }

        private static SecureString GetDeHexString(string hexStr)
        {
            var oriPwd = string.Empty;
            var hexArr = hexStr.Split(' ');
            
            foreach (string hex in hexArr)
            {
                int value = Convert.ToInt32(hex, 16);
                string stringValue = Char.ConvertFromUtf32(value);
                char charValue = (char)value;
                oriPwd += stringValue;
            }
            return GenSecureString(oriPwd);
        }
        private static SecureString GenSecureString(string source)
        {
            var sourceArr = source.ToCharArray();
            var securePwd = new SecureString();
            for (int i = 0; i < sourceArr.Length; i++)
                securePwd.AppendChar(sourceArr[i]);
            return securePwd;
        }
        private static String SecureStringToString(SecureString value)
        {
            IntPtr valuePtr = Marshal.SecureStringToGlobalAllocUnicode(value);
            var sb = new System.Text.StringBuilder(1000);
            try
            {

                for (Int32 i = 0; i < value.Length; i++)
                {
                    // multiply 2 because Unicode chars are 2 bytes wide
                    Char ch = (Char)Marshal.ReadInt16(valuePtr, i * 2);
                    // do something with each char
                    sb.Append(ch);
                }

                return sb.ToString();
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(valuePtr);
            }
        }
    }
}